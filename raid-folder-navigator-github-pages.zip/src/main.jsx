import React, { useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  FolderOpen, Search, Image, Map, SlidersHorizontal, RefreshCw,
  ChevronDown, FileImage, X, CheckCircle2, HardDrive, ArrowUpDown,
  LayoutGrid, List, Info, Shield, Compass
} from "lucide-react";
import "./style.css";

const MAPS = ["Все локации", "Woods", "Customs", "Shoreline", "Interchange", "Reserve", "Lighthouse", "Streets of Tarkov", "Ground Zero", "Factory", "The Lab"];
const IMAGE_EXT = /\.(png|jpe?g|webp|gif|bmp|tiff?)$/i;

function cleanName(filename) {
  return filename.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ").trim();
}
function detectMap(name) {
  const s = name.toLowerCase();
  const aliases = [
    ["Woods", ["woods", "лес"]],
    ["Customs", ["customs", "тамож"]],
    ["Shoreline", ["shoreline", "берег"]],
    ["Interchange", ["interchange", "развяз"]],
    ["Reserve", ["reserve", "резерв"]],
    ["Lighthouse", ["lighthouse", "маяк"]],
    ["Streets of Tarkov", ["streets", "улицы"]],
    ["Ground Zero", ["ground zero", "эпицентр"]],
    ["Factory", ["factory", "завод"]],
    ["The Lab", ["the lab", "laboratory", "лаборатор"]]
  ];
  return aliases.find(([map, words]) => words.some(w => s.includes(w)))?.[0] || "Не определена";
}
function formatSize(bytes) {
  if (!bytes) return "—";
  return bytes < 1024 * 1024 ? `${(bytes / 1024).toFixed(0)} КБ` : `${(bytes / 1024 / 1024).toFixed(1)} МБ`;
}
function App() {
  const inputRef = useRef(null);
  const [items, setItems] = useState([]);
  const [folderName, setFolderName] = useState("");
  const [query, setQuery] = useState("");
  const [mapFilter, setMapFilter] = useState("Все локации");
  const [sort, setSort] = useState("name");
  const [view, setView] = useState("list");
  const [selected, setSelected] = useState(null);
  const [status, setStatus] = useState("");

  const loadFiles = (fileList) => {
    const all = Array.from(fileList || []);
    const images = all.filter(f => IMAGE_EXT.test(f.name)).map((f, i) => ({
      id: `${f.name}-${f.lastModified}-${i}`,
      name: f.name,
      title: cleanName(f.name),
      map: detectMap(f.name),
      size: f.size,
      modified: f.lastModified,
      path: f.webkitRelativePath || f.name
    }));
    setItems(images);
    setSelected(null);
    setQuery("");
    setMapFilter("Все локации");
    const firstPath = all[0]?.webkitRelativePath || "";
    setFolderName(firstPath ? firstPath.split("/")[0] : `${images.length} файлов`);
    setStatus(images.length ? `Найдено изображений: ${images.length}` : "В выбранной папке не найдено изображений");
  };

  const chooseFolder = async () => {
    // Native folder picker is supported by Chromium-based desktop browsers.
    if (window.showDirectoryPicker) {
      try {
        const dir = await window.showDirectoryPicker({ mode: "read" });
        const found = [];
        const walk = async (handle, prefix = "") => {
          for await (const [name, entry] of handle.entries()) {
            if (entry.kind === "file") {
              const file = await entry.getFile();
              Object.defineProperty(file, "webkitRelativePath", { value: prefix ? `${prefix}/${name}` : name });
              found.push(file);
            } else if (entry.kind === "directory") {
              await walk(entry, prefix ? `${prefix}/${name}` : name);
            }
          }
        };
        await walk(dir);
        setFolderName(dir.name);
        loadFiles(found);
        setFolderName(dir.name);
      } catch (e) {
        if (e.name !== "AbortError") setStatus("Не удалось прочитать папку. Попробуй выбрать её через стандартное окно.");
      }
    } else {
      inputRef.current?.click();
    }
  };

  const filtered = useMemo(() => {
    let result = items.filter(item => {
      const matchesQuery = `${item.name} ${item.title} ${item.path}`.toLowerCase().includes(query.toLowerCase());
      const matchesMap = mapFilter === "Все локации" || item.map === mapFilter;
      return matchesQuery && matchesMap;
    });
    result.sort((a, b) => sort === "date" ? b.modified - a.modified : a.title.localeCompare(b.title, "ru"));
    return result;
  }, [items, query, mapFilter, sort]);

  const mapCounts = useMemo(() => items.reduce((acc, item) => {
    acc[item.map] = (acc[item.map] || 0) + 1;
    return acc;
  }, {}), [items]);

  const reset = () => {
    setItems([]); setFolderName(""); setSelected(null); setQuery("");
    setMapFilter("Все локации"); setStatus("");
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><Compass size={22}/></div>
          <div><div className="brand-name">RAID<span>INDEX</span></div><div className="brand-sub">LOCAL SCREENSHOT CATALOG</div></div>
        </div>
        <div className="top-meta"><span className="live-dot"/> ЛОКАЛЬНЫЙ РЕЖИМ <span className="top-divider"/> v1.0</div>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <div className="side-label">РАЗДЕЛЫ</div>
          <div className="nav-item active"><LayoutGrid size={17}/> Обзор папки</div>
          <div className="nav-item"><Map size={17}/> Каталог скриншотов</div>
          <div className="side-divider"/>
          <div className="side-label">ЛОКАЦИИ</div>
          <button className={`map-link ${mapFilter === "Все локации" ? "chosen" : ""}`} onClick={() => setMapFilter("Все локации")}><span className="map-dot"/> Все локации <b>{items.length}</b></button>
          {MAPS.slice(1).map(map => (
            <button key={map} className={`map-link ${mapFilter === map ? "chosen" : ""}`} onClick={() => setMapFilter(map)}>
              <span className="map-dot"/>{map}<b>{mapCounts[map] || 0}</b>
            </button>
          ))}
          <div className="sidebar-bottom">
            <Shield size={15}/> <span>Файлы остаются на твоём устройстве.</span>
          </div>
        </aside>

        <main className="main">
          <div className="page-heading">
            <div><div className="eyebrow">WORKSPACE / FILE BROWSER</div><h1>Обзор скриншотов</h1><p>Каталог изображений по названиям файлов — без просмотра их содержимого.</p></div>
            <button className="outline-btn" onClick={reset}><RefreshCw size={15}/> Сбросить</button>
          </div>

          <section className="folder-card">
            <div className="folder-icon"><FolderOpen size={25}/></div>
            <div className="folder-copy">
              <strong>{folderName || "Папка не выбрана"}</strong>
              <span>{folderName ? `${items.length} изображений в каталоге` : "Выбери папку со своими скриншотами, чтобы начать"}</span>
            </div>
            <button className="primary-btn" onClick={chooseFolder}><FolderOpen size={16}/> Выбрать папку</button>
            <input ref={inputRef} type="file" accept="image/*" multiple webkitdirectory="true" directory="" className="hidden-input" onChange={e => loadFiles(e.target.files)}/>
          </section>

          <div className="stats-row">
            <div className="stat-card"><div className="stat-icon"><Image size={17}/></div><div><span>ИЗОБРАЖЕНИЯ</span><strong>{items.length}</strong></div></div>
            <div className="stat-card"><div className="stat-icon"><Map size={17}/></div><div><span>РАСПОЗНАНО ЛОКАЦИЙ</span><strong>{Object.keys(mapCounts).filter(x => x !== "Не определена").length}</strong></div></div>
            <div className="stat-card"><div className="stat-icon"><HardDrive size={17}/></div><div><span>В РЕЗУЛЬТАТЕ</span><strong>{filtered.length}</strong></div></div>
          </div>

          <section className="content-card">
            <div className="content-head">
              <div><h2>Файлы</h2><span className="muted">{status || "Сначала выбери папку"}</span></div>
              <div className="view-switch">
                <button className={view === "list" ? "selected" : ""} onClick={() => setView("list")} aria-label="Список"><List size={17}/></button>
                <button className={view === "grid" ? "selected" : ""} onClick={() => setView("grid")} aria-label="Сетка"><LayoutGrid size={16}/></button>
              </div>
            </div>
            <div className="toolbar">
              <div className="searchbox"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Поиск по названию файла..."/>{query && <button onClick={() => setQuery("")}><X size={14}/></button>}</div>
              <div className="filter-control"><SlidersHorizontal size={15}/><select value={mapFilter} onChange={e => setMapFilter(e.target.value)}>{MAPS.map(m => <option key={m}>{m}</option>)}</select><ChevronDown size={14}/></div>
              <button className="sort-btn" onClick={() => setSort(sort === "name" ? "date" : "name")}><ArrowUpDown size={15}/>{sort === "name" ? "По имени" : "Сначала новые"}</button>
            </div>

            {filtered.length ? (
              <div className={view === "grid" ? "file-grid" : "file-list"}>
                {filtered.map(item => (
                  <button key={item.id} className={`file-row ${selected?.id === item.id ? "file-active" : ""}`} onClick={() => setSelected(item)}>
                    <div className="file-type"><FileImage size={19}/></div>
                    <div className="file-info"><strong>{item.title}</strong><span>{item.path}</span></div>
                    <span className={`map-tag ${item.map === "Не определена" ? "unknown" : ""}`}>{item.map}</span>
                    <span className="file-size">{formatSize(item.size)}</span>
                  </button>
                ))}
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-icon"><FolderOpen size={27}/></div>
                <strong>{items.length ? "Ничего не найдено" : "Здесь пока пусто"}</strong>
                <span>{items.length ? "Измени поисковый запрос или фильтр локации." : "Выбери папку. Сайт прочитает только имена файлов и их расширения."}</span>
              </div>
            )}
          </section>
          <footer><span>RAID INDEX</span><span>Никакие изображения не загружаются и не анализируются.</span></footer>
        </main>

        <aside className="details">
          <div className="details-title"><span>ИНФОРМАЦИЯ О ФАЙЛЕ</span><Info size={16}/></div>
          {selected ? <>
            <div className="detail-file-icon"><FileImage size={30}/></div>
            <h3>{selected.title}</h3>
            <p className="detail-filename">{selected.name}</p>
            <div className="detail-sep"/>
            <div className="detail-line"><span>Локация</span><b>{selected.map}</b></div>
            <div className="detail-line"><span>Размер</span><b>{formatSize(selected.size)}</b></div>
            <div className="detail-line"><span>Формат</span><b>{selected.name.split(".").pop().toUpperCase()}</b></div>
            <div className="detail-line"><span>Путь</span><b className="path-value">{selected.path}</b></div>
            <div className="privacy-note"><CheckCircle2 size={16}/> Информация получена из имени файла. Само изображение не открывалось.</div>
          </> : <div className="details-empty"><FileImage size={25}/><span>Выбери файл в списке, чтобы увидеть его свойства.</span></div>}
        </aside>
      </div>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);